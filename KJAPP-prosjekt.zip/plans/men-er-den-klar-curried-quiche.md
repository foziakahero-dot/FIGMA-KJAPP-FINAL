# Plan: Status, endringer og veien videre for KJAPP

## Context
Brukeren spør tre ting:
1. Er appen klar for testing?
2. Hva skjer hvis vi vil gjøre endringer senere?
3. Bør vi lage et admin-panel (skrivebord)?

Dette er en vurdering/anbefaling, ikke en kodeoppgave.

---

## 1. Er appen klar for testing?

### Hva fungerer nå (✅)
- **Turbestilling** — Kunde ber om tur → sjåfør godtar → statuser oppdateres. Full ride-lifecycle (requested → accepted → driver_arrived → in_progress → completed).
- **Kart** — Google Places, autocomplete, veibeskrivelse — fungerer med stub-modus hvis API-nøkkel mangler.
- **Prisberegning** — Eco/Standard/Premium/XL med MVA 12%, plattformavgift 10%, sjåfør-utbetaling.
- **GDPR** — Samtykkelogging, dataeksport (Art.15), sletting (Art.17) — produksjonsklar.
- **Database** — 3 migrasjoner, RLS-policyer, 4 brukerroller.
- **EAS Build** — app.json og eas.json satt opp, GitHub Actions workflow klar.

### Hva mangler før pilot (⚠️)
| Mangler | Alvor | Workaround |
|---------|-------|------------|
| Google Maps API-nøkkel i Supabase | Kritisk | Stubs returnerer Oslo-koordinater |
| GitHub Secrets ikke satt | Kritisk | Migrasjoner kjøres ikke automatisk |
| Betaling (Stripe/Vipps) | Middels | Kan teste uten betaling i pilot |
| SMS-OTP (LinkMobility) | Middels | Kan bruke e-post-OTP via Supabase Auth |
| Expo assets (icon.png, splash.png) | Middels | Bygg feiler uten disse |

### Konklusjon
**Ja — klar for intern pilot-testing** etter at 2 ting er på plass:
1. Sett inn `GOOGLE_MAPS_API_KEY` i Supabase Dashboard
2. Sett inn 5 GitHub Secrets (se under)

---

## 2. Hva om vi vil gjøre endringer?

### Arbeidsflyt for endringer
Alle fremtidige endringer gjøres her i Figma Make:
- Rediger komponent → Figma Make oppdaterer koden
- Push til GitHub (med token vi allerede har satt opp)
- GitHub Actions kjøres automatisk → ny APK/IPA bygges

### Prioriterte neste endringer (anbefalt rekkefølge)
1. **Legg til Expo-assets** — icon.png, splash.png (ellers feiler EAS-bygg)
2. **SMS-OTP via Supabase** — Bytt ut mock-OTP med ekte Supabase Auth
3. **Stripe betaling** — Koble inn Stripe-endepunktene som allerede er i databasen
4. **Supabase Realtime** — Bytt polling (4s) med WebSocket-subscriptions
5. **Vipps betaling** — Norsk standard, viktig for lansering

---

## 3. Admin-panel — beste løsning

### Anbefaling: IKKE bygge admin her

Prosjektet er låst som "KJAPP Mobile App Prototype" (se MEMORY). Admin-panel hører ikke hjemme her.

### Beste alternativ: Supabase Studio (gratis, ingen kode)
Supabase Dashboard gir deg alt du trenger nå:
- Se alle turer, brukere, sjåfører i databasen
- Godkjenn løyvehaver-søknader manuelt via SQL
- GDPR-sletting og eksport
- Realtime tabellvisning

URL: **supabase.com/dashboard/project/[ditt-project-ref]**

### Hvis du LATER vil ha admin-panel
Lag et **separat prosjekt** i Figma Make — "KJAPP Admin" — med:
- Flåteoversikt (sjåfører online/offline)
- Turhistorikk og økonomi
- Godkjenning av løyvehaver-søknader
- Live kart med alle biler

Dette holder mobilappen ren og admin-koden separat.

---

## Umiddelbare steg for å komme i gang med testing

### GitHub Secrets (gjøres én gang)
Gå til: github.com/foziakahero-dot/FIGMA-KJAPP-FINAL/settings/secrets/actions

| Secret | Hvor du finner den |
|--------|-------------------|
| `SUPABASE_URL` | Supabase Dashboard → Settings → API |
| `SUPABASE_ANON_KEY` | Supabase Dashboard → Settings → API |
| `SUPABASE_ACCESS_TOKEN` | supabase.com/dashboard/account/tokens |
| `SUPABASE_PROJECT_REF` | Supabase Dashboard → Settings → General |
| `GOOGLE_MAPS_API_KEY` | console.cloud.google.com |
| `EXPO_TOKEN` | expo.dev/accounts/[bruker]/settings/access-tokens |

### EAS Build — APK
Etter at EXPO_TOKEN er satt:
GitHub → Actions → "EAS Build (APK/iOS)" → Run workflow → android → preview → **APK klar på ~10 min**

## Ingen kodeendringer nødvendig i denne planen
Dette er en status- og anbefalingsplan. Neste kodeoppgave er å legge til Expo-assets (icon + splash) for at EAS-bygget skal fungere.
